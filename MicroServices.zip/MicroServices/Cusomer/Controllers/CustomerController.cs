﻿using Microsoft.AspNetCore.Mvc;

namespace CusomerServices.Controllers
{
    [ApiController]
     public class CustomerController : ControllerBase
    {
        [HttpGet]
        [Route("GetCustomer")]
        public List<string> Get()
        {
            var _customer = new List<string> { "Customer 1", "Customer 2", "Customer 3" };
            return _customer;
        }
    }
}
