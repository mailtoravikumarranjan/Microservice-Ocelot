﻿using Microsoft.AspNetCore.Mvc;

namespace ProductServices.Controllers
{
    [ApiController]
   public class ProductController : ControllerBase
    {
        [HttpGet]
        [Route("GetProduct")]
        public List<string> Get()
        {
            var _product= new List<string> { "Product 1", "Product 2", "Product 3" };
            return _product;
        }
    }
}
